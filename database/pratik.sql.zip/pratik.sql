-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 22, 2014 at 04:28 PM
-- Server version: 5.1.36-community-log
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pratik`
--

-- --------------------------------------------------------

--
-- Table structure for table `gifts`
--

CREATE TABLE IF NOT EXISTS `gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `image` varchar(60) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0=inactive,1=active',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `gifts`
--

INSERT INTO `gifts` (`id`, `user_id`, `title`, `image`, `status`, `created`, `modified`) VALUES
(1, 1, 'First Gift Hurre', '16426_Chrysanthemum.jpg', 1, '0000-00-00 00:00:00', '2014-09-21 18:00:30');

-- --------------------------------------------------------

--
-- Table structure for table `memorialcandles`
--

CREATE TABLE IF NOT EXISTS `memorialcandles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memorial_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `candle_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0=inactive,1=active',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `memorialgifts`
--

CREATE TABLE IF NOT EXISTS `memorialgifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memorial_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `gift_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0=inactive,1=active',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `memorials`
--

CREATE TABLE IF NOT EXISTS `memorials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(10) NOT NULL,
  `firstname` varchar(60) NOT NULL,
  `middlename` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `dob_day` int(11) NOT NULL,
  `dob_month` int(11) NOT NULL,
  `dob_year` int(11) NOT NULL,
  `dop_day` int(11) NOT NULL,
  `dop_month` int(11) NOT NULL,
  `dop_year` int(11) NOT NULL,
  `city` varchar(60) NOT NULL,
  `death_cause` varchar(100) NOT NULL,
  `related_person` varchar(60) NOT NULL,
  `message` text NOT NULL,
  `img` varchar(60) NOT NULL,
  `viewcount` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0=inactive,1=active',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `memorials`
--

INSERT INTO `memorials` (`id`, `user_id`, `title`, `firstname`, `middlename`, `lastname`, `dob_day`, `dob_month`, `dob_year`, `dop_day`, `dop_month`, `dop_year`, `city`, `death_cause`, `related_person`, `message`, `img`, `viewcount`, `status`, `created`, `modified`) VALUES
(9, 1, 'Mrs', 'Person', 'M', 'Last', 1, 1, 1998, 1, 1, 1998, 'Abad', 'General', 'XZS', 'This is sample message.', '', 0, 1, '2014-09-20 11:49:37', '2014-09-20 11:49:37'),
(8, 1, 'Mrs', 'updated hurey', 'sadfsd', 'sda', 1, 1, 1998, 1, 1, 1998, 'sdaf', 'asf', 'sadf', 'lore impsu m <span style="color:#ff0000;">etseat</span> sakdjs fajdfa <span style="color:#00ffff;">jlfj</span> l ja\r\nUpdate dinformation saved\r\n \r\n<b>\r\n</b>', '83536_Penguins.jpg', 0, 1, '2014-09-16 17:41:26', '2014-09-21 07:17:35');

-- --------------------------------------------------------

--
-- Table structure for table `tributes`
--

CREATE TABLE IF NOT EXISTS `tributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memorial_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0=inactive,1=active',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tributes`
--

INSERT INTO `tributes` (`id`, `memorial_id`, `user_id`, `message`, `status`, `created`, `modified`) VALUES
(1, 8, 21, 'first tribute updated finally done.', 1, '0000-00-00 00:00:00', '2014-09-21 16:43:00');

-- --------------------------------------------------------

--
-- Table structure for table `usermetas`
--

CREATE TABLE IF NOT EXISTS `usermetas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `firstname` varchar(60) DEFAULT NULL,
  `middlename` varchar(60) DEFAULT NULL,
  `lastname` varchar(60) DEFAULT NULL,
  `add_lineone` varchar(60) DEFAULT NULL,
  `add_linetwo` varchar(60) DEFAULT NULL,
  `city` varchar(60) DEFAULT NULL,
  `state` varchar(60) DEFAULT NULL,
  `zip` int(10) DEFAULT NULL,
  `dob_day` int(11) DEFAULT NULL,
  `dob_month` int(11) DEFAULT NULL,
  `dob_year` int(11) DEFAULT NULL,
  `gender` tinyint(4) DEFAULT NULL COMMENT '0=not to specify,1=male,2=female',
  `image` varchar(80) DEFAULT NULL,
  `flag` tinyint(4) DEFAULT '0' COMMENT '0=work,1=deleted',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `usermetas`
--

INSERT INTO `usermetas` (`id`, `user_id`, `firstname`, `middlename`, `lastname`, `add_lineone`, `add_linetwo`, `city`, `state`, `zip`, `dob_day`, `dob_month`, `dob_year`, `gender`, `image`, `flag`, `created`, `modified`) VALUES
(1, 1, 'Anuj', 'Y', 'Jaha', 'Address-1', 'Add-2', 'Ahbe', 'TS', 1002, 0, 0, 0, 1, '', 0, '0000-00-00 00:00:00', '2014-09-20 17:54:57'),
(7, 21, 'Yogesh', 'S', 'Jaha', 'E-12 Susmita Flat', 'Vasna', 'Abad', 'Gujarat', 10091, 23, NULL, NULL, NULL, NULL, 0, '2014-09-20 18:24:19', '2014-09-20 18:24:19'),
(6, 20, '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2014-09-20 17:33:13', '2014-09-20 17:33:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=user,1=admin',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0=inactive,1=active',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `status`, `created`, `modified`) VALUES
(1, 'anuj', '$2a$10$UuoG6uPzfM1VWF98FfcAv.1sY5hhuzEORnmACdQ2gFP3fqXoc/GOG', 1, 1, '2014-09-18 18:16:03', '2014-09-20 17:54:57'),
(21, 'yogesh', '$2a$10$HraTMfyVa9Kumbx.S9PpE.wvHoLCEc.TUuhfQetaWEVnbZhZTHToW', 0, 1, '2014-09-20 18:24:19', '2014-09-20 18:24:19');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
