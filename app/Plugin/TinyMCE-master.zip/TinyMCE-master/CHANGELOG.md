Changelog
=========

Release 1.2.0
-------------

https://github.com/CakeDC/TinyMCE/tree/1.2.0

 * [4b1d286](https://github.com/CakeDC/TinyMCE/commit/4b1d286) Working on making the plugin match the CakeDC plugin standard
 * [805530e](https://github.com/CakeDC/TinyMCE/commit/805530e) Adding files for the plugin standard
 * [5b187e1](https://github.com/CakeDC/TinyMCE/commit/5b187e1) Update TinyMCEHelper.php
 * [60c53a4](https://github.com/CakeDC/TinyMCE/commit/60c53a4) Updating TinyMCE to 4.0.26
 * [12c5169](https://github.com/CakeDC/TinyMCE/commit/12c5169) Refactoring the helper a little
 * [299baed](https://github.com/CakeDC/TinyMCE/commit/299baed) Adding TinyMCE 4.0.10 Jquery, keeping the old version 3 as default.
 * [92dd568](https://github.com/CakeDC/TinyMCE/commit/92dd568) Updating TinyMCE to 3.5.10